# Todo

## To Do

## In Progress

[ ] Add documentation
[ ] Add comments to the code

## Completed

[x] Add logging - 2026-03-11
[x] Improve code structure - 2026-03-11
[x] List installed packages - 2026-03-10
[x] Improve command line arguments - 2026-03-07
[x] Add help message for command line arguments that do not already have them - 2026-03-07
