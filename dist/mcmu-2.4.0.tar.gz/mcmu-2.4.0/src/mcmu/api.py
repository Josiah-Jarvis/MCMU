#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""ModrinthAPI class"""

from hashlib import sha1, sha512
from pathlib import Path
from requests import get
from . import __version__


USER_AGENT = "Josiah-Jarvis/MCMU/"
USER_AGENT += f"{__version__} "
USER_AGENT += "(https://github.com/Josiah-Jarvis/MCMU)"


class ModrinthAPI:
    """Modrinth API class"""
    def __init__(self):
        self.headers = {
            'User-Agent': USER_AGENT,
        }

    def query(
        self,
        endpoint: str = "https://api.modrinth.com/v2/",  # The API endpoint
        parameters: dict = None  # The parameters to pass the API
    ) -> dict:  # API json
        """Query's the Modrinth API

        Raises:
            DeprecationWarning: If response is 410
            UserWarning: If response is 400 or 404
        """
        response = get(
            url=f"https://api.modrinth.com/v2/{endpoint}",
            params=parameters,
            headers=self.headers,
            timeout=10
        )
        if response.status_code == 410:
            raise DeprecationWarning("Modrinth API deprecated")
        if response.status_code == 404:
            raise UserWarning(f"Mod: {endpoint} not found")
        if response.status_code == 400:
            raise UserWarning("API request invalid")
        return response.json()

    def search(
        self,
        query: str,  # The query string
        index: str,  # The filter
        offset: int,  # The offset
        facets: str,  # Used to limit the search results see
        limit: int  # The max number of results
    ) -> [dict]:  # Response data
        """Search's Mod on Modrinth"""
        parameters = {
            'query': query,
            'facets': facets,
            'index': index,
            'offset': offset,
            'limit': limit
        }
        return self.query("search", parameters)

    def project(
        self,
        slug: str  # The slug of the project
    ) -> [dict]:  # Project data
        """Get data about a project"""
        return self.query(f"project/{slug}")

    def project_dependencies(
        self,
        slug: str  # The slug of the project
    ) -> [dict]:  # Dependency information
        """Get a list of a projects dependencies"""
        return self.query(f"project/{slug}/dependencies")

    def project_version(
        self,
        slug: str,  # The slug of the project
        loaders: str,  # Loaders to filter for
        version: str  # Game versions to filter for
    ) -> [dict]:  # Project version data
        """List a projects versions"""
        parameters = {
            'loaders': loaders,
            'game_versions': version,
            'include_changelog': 'false'
        }
        return self.query(f"project/{slug}/version", parameters)

    def get_project_version(
        self,
        slug: str,  # The name of the project
        version_number: str  # The specific version of the project
    ) -> [dict]:  # The query's json
        """Get a specific version from a mod"""
        return self.query(f"project/{slug}/version/{version_number}")

    def get_file(
        self,
        file: str,  # The file to download
        path: Path,  # The file to write to
        hash_list: list  # The  hashs
    ) -> bool:  # True if success
        """Gets file from the CDN
        Raises:
            UserWarning: 404 code, hash's do not match
            PermissionError: No permission to write to file
        """
        response = get(file, stream=True, timeout=10, headers=self.headers)
        if response.status_code == 404:
            raise UserWarning("Version file failed to download")
        try:
            hash_sha1 = sha1(usedforsecurity=False)
            hash_sha512 = sha512(usedforsecurity=False)
            with open(path, 'wb') as jar_file:  # Write to the jar file
                for chunk in response.iter_content(chunk_size=1024):
                    if chunk:
                        jar_file.write(chunk)
                        hash_sha1.update(chunk)
                        hash_sha512.update(chunk)
            if (
                hash_sha1.hexdigest() == hash_list['sha1']
            ) and (
                hash_sha512.hexdigest() == hash_list['sha512']
            ):
                return True
            raise UserWarning("Hash's do not match")
        except PermissionError as exc:
            raise PermissionError(f"No permission to write: {path}") from exc
