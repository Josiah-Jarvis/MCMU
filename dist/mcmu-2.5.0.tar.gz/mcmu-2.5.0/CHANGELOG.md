# Changelog

## [v2.5.0] - 2026-09-28

### Changed

* Bumped game version to 26.3
* Removed checking sha1

## [v2.5.0.dev1] - 2026-09-27

### Changed

* Bumped game version to 26.3

### Removed

* Removed checking sha1

## [v2.4.0] - 2026-07-03

Version 2.4.0 is finally here!

## [v2.4.0.dev4] - 2026-06-23

### Added

* Added list --disabled
* Added list --enabled
* Now can list enabled and disabled mods separately
* Added search --sorting
* Added search --offset
* Added search --limit

### Changed

* -c/--channel is now under the update_parser/install_parser instead of the main parser
* -l/--loader is now under the update_parser/install_parser instead of the main parser
* --game-version is now under the update_parser/install_parser instead of the main parser
* Further improved how search --client-side and search --server-side work
* Now makes sure environment variables MCMU_MOD_LOADER and MCMU_GAME_VERSION are valid

### Removed

* -c/--channel can now only be referred to as --channel
* -l/--loader can now only be referred to as --loader
* Removed --verbose flag as logging.debug() was unused in the code

### Fixed

* Added search --loader option that previously was not there but referenced
* search --open-source

## [v2.4.0.dev3] - 2026-06-19

### Added

* Added search --category CLI argument
* Added search --versions CLI argument
* Added search --server-side CLI argument
* Added search --client-side CLI argument
* Added search --open-source CLI argument

### Changed

* Changed search system

## [v2.4.0.dev2] - 2026-06-18

### Changed

* Updated README.md
* Updated Makefile

## [v2.4.0.dev1] - 2026-06-17

### Added

* Added the -c/--channel command line argument

### Changed

* The command line argument --loader can now be referred to as -l
* Changed exit code of CTRL+C to 130 [https://www.thelinuxvault.net/blog/list-of-exit-codes-on-linux/#exit-code-130-terminated-by-ctrlc](https://www.thelinuxvault.net/blog/list-of-exit-codes-on-linux/#exit-code-130-terminated-by-ctrlc)

### Removed

* Removed the --beta option
* Removed -y/--yes command line argument because I did not like its implementation
* Removed the backup command

## [v2.3.0] - 2026-06-16

### Added

* Added -y/--yes command line argument
* Added support for multiple mod loaders
* Added environment variable MCMU_MOD_LOADER
* Added --loader command line argument
* Added --beta command line argument
* Now checks sha1 and sha512 hashes of downloaded files for better security

### Fixed

* Fixed only printing last dependency with 'mcmu info PROJECT'
* Fixed printing mod() object address instead of mod name when removing a mod
* Fixed failing on CTL+C
* Fixed only checking sha1 or sha512, now checks both

### Changed

* Changed ordering of arguments in help message
* Now on install/update only downloads latest stable unless told to download beta/alpha
* Changed system recognition code to now go MacOS, Windows, Linux
* Bump default Minecraft game version to 26.2 in preparation for the Chaos Cubed update
* No longer raises UserWarning when mod already enabled/disabled
* No longer prints default arguments for mcmu --help
* Now only allows .tar/.tar.gz/.zip archives to be made

## [v2.3.0rc1] - 2026-06-05

First release candidate for version 2.3.0. Version 2.3.0 will be released June 16th.

## [v2.3.0.dev3] - 2026-05-19

### Fixed

* Fixed only checking sha1 or sha512, now checks both

### Changed

* Changed system recognition code to now go MacOS, Windows, Linux
* Bump default Minecraft game version to 26.2 in preparation for the Chaos Cubed update
* No longer raises UserWarning when mod already enabled/disabled
* No longer prints default arguments for mcmu --help
* Now only allows .tar/.tar.gz/.zip archives to be made

## [v2.3.0.dev2] - 2026-05-15

### Added

* Now checks sha1 and sha512 hashes of downloaded files for better security

### Fixed

* Fixed failing on CTL+C

## [v2.3.0.dev1] - 2026-05-9

### Added

* Added -y/--yes command line argument
* Added support for multiple mod loaders
* Added environment variable MCMU_MOD_LOADER
* Added --loader command line argument
* Added --beta command line argument

### Fixed

* Fixed only printing last dependency with 'mcmu info PROJECT'
* Fixed printing mod() object address instead of mod name when removing a mod

### Changed

* Changed ordering of arguments in help message
* Now on install/update only downloads latest stable unless told to download beta/alpha

## [v2.2.0] - 2026-05-02

Version 2.2.0.

### Added

* Can now enable and disable mods
* Added enable command
* Added disable command
* Now can get mod path and game version form environment variables
* Can now back up mods folder into an archive
* Added -v/--version option

### Changed

* Changed --mod_dir to --mod-dir
* Now the default path to the mods folder is os dependent
* Split up code into multiple files
* Disabled mods now become '.jar.disabled' instead of going into the 'mods_disabled/' folder
* Changed argument group into sub parser commands
* Updated documentation to v2.2.0
* Updated all log messages

### Removed

* Removed support for Python 3.13
* Removed -d/--dependency

### Fixed

* Fixed when --mod-dir has not .jar files (AttributeError: 'NoneType' object has no attribute 'group')
* Fixed errors with install and info related to mods not existing on Modrinth.
* Fixed errors with enable and disable related to mods not being installed.

## [v2.2.0rc0] - 2026-05-01

If no problems are found this will become version 2.2.0.

## Changed

* Updated documentation to v2.2.0
* Updated all log messages

## Fixed

* Fixed errors with install and info related to mods not existing on Modrinth.
* Fixed errors with enable and disable related to mods not being installed.

## [v2.2.0.dev3] - 2026-04-29

### Changed

* Changed argument group into sub parser commands

### Added

* Added -v/--version option

## [v2.2.0.dev2] - 2026-04-28

### Added

* Can now back up mods folder into an archive

### Changed

* Disabled mods now become '.jar.disabled' instead of going into the 'mods_disabled/' folder

### Removed

* Removed '--enable-experimental-features' option

## [v2.2.0.dev1] - 2026-04-27

### Added

* Can now enable and disable mods
* Added -e/--enable option
* Added -d/--disable option
* Added --enable-experimental-features
* Now can get mod path and game version form environment variables

### Changed

* Split up code into multiple files

## [v2.2.0.dev0] - 2026-04-24

### Changed

* Updated game version to 26.2
* Changed --mod_dir to --mod-dir
* Now the default path to the mods folder is os dependent
* --game-version default is now 26.1.2 again

### Removed

* Removed support for Python 3.13
* Removed -d/--dependency

### Fixed

* Fixed when --mod-dir has not .jar files (AttributeError: 'NoneType' object has no attribute 'group')

## [v2.1.3] - 2026-04-09

### Fixed

* Actually fixed it this time

### Changed

* Changed default minecraft version to 26.1.2

## [v2.1.2] - 2026-04-08

### Fixed

* Fixed printing debug messages for real this time

## [v2.1.1] - 2026-04-08

### Fixed

* Fixed printing debug messages

## [v2.1.0] - 2026-04-08

WooHoo version 2.1.0 is now here!

## [v2.1.0rc0] - 2026-04-07

Here is the first release candidate for v2.1.0.

### Changed

* Updated default version to 26.1.1 from 26.1

### Fixed

* Fixed when canceling the update of one mod it stops all others from updating

## [v2.0.1.dev1] - 2026-03-24

### Fixed

* Fixed not checking if mod installed before installing if version specified
* Fixed FileNotFoundError: [Errno 2] No such file or directory: 'mods_folder'

### Changed

* Changed --minecraft-dir to --mod-dir

### Added

* Added the -p/--project option

### Removed

* Removed -d/--dependency

## [v2.0.1.dev0] - 2026-03-23

Here is the first snapshot for the WaterBucket update, enjoy!

### Added

* Now shows the defaults values for arguments in the help menu

### Changed

* Separated different command codes into separate functions instead of all in *main()*
* Now raises a DeprecationWarning and a UserWarning for when the API fails
* Can now install specific versions of a mod
* --update is --up
* --game_version is now --game-version
* --minecraft_dir is now --minecraft-dir

### Removed

* No longer shows help message if no args are passed
* Removed the -m and -g short arguments

## [v2.0.0] - 2026-03-20

Here's version 2.0.0! Hope it works.

## [v2.0.0rc0] - 2026-03-19

### Added

* Added ability to list a projects dependency's

### Changed

* Moved API code from *ModrinthAPI.py* into *__main__.py*

## [v2.0.0.dev3] - 2026-03-18

### Added

* Now installs a mods required dependency's

### Changed

* Changed help message to display version at bottom

## [v2.0.0.dev2] - 2026-03-17

### Changed

* Now shows 100 search results instead of 10

### Removed

* Removed -v and --version

## [v2.0.0.dev1] - 2026-03-17

### Changed

* Changed the name of the file when downloading

### Removed

* Removed the need for the config file

### Fixed

* Fixed displaying mod name when upgrading

## [v1.4.0.dev0] - 2026-03-16

### Added

* Added a user agent header to reduce the likely hood Modrinth blocks the client

### Changed

* Put API request code into separate file *ModrinthAPI.py*

## [v1.3.0] - 2026-03-15

### Added

* Comments to the code

## [v1.3.0a1] - 2026-03-15

### Removed

* Removed print statement for parameters

## [v1.3.0a0] - 2026-03-15

This release brings a new feature! You can now search mods on Modrinth!

### Added

* Functionality to search mods

### Fixed

* Fixed passing parameters for installing mods

### Changed

* Does'nt ask to download mod if it is already installed
* Now most command lines options are mutually exclusive

## [v1.2.1] - 2026-03-13

### Changed

* Change help message for the -g command line argument

## [v1.2.0] - 2026-03-13

Happy Pi days for reals this time

No changes from [1.2.0rc0](#v120rc0---2026-03-13)

## [v1.2.0rc0] - 2026-03-13

If no serious bugs are found this release will become [1.2.0](#v120---2026-03-13)

### Fixed

* Fixed mod failing to update because of "AttributeError: 'PosixPath' object has no attribute 'stats'. Did you mean: 'stat'?"
* Fixed when updating mods a new mod entry is made titled null breaking future update runs

### Changed

* Took check_update() code out of Mod class

### Removed

* Removed Mod class

## [v1.2.0a1] - 2026-03-13

### Changed

* Now shows additional storage that will be taken up by updating a mod
* Now uses Mod.check_update() instead of Mod.install() when installing a mod

### Removed

* Removed Mod.install()

## [v1.2.0a0] - 2026-03-13

### Added

* Shows space that will be taken up by a new mod
* Shows space that will be saved when removing a mod

### Changed

* Now asks for permission to install mod
* Now asks for permission to remove mod
* Moved *minecraft_mod.py* code into *__main__.py*

## [v1.2.0.dev1] - 2026-03-13

### Added

* Added a message when a mod is removed

## [v1.2.0.dev0] - 2026-03-13

### Changed

* Made update messages pretty

## [v1.1.1] - 2026-03-13

Happy almost Pi Day! Here is the newest stable release.

### Changed

* Changed sys.exit() to return statements.

## [1.1.1a0] - 2026-03-12

1.1.1 is scheduled for 14 March 2026 (Pi day)

### Changed

* Changed default version for Minecraft to 26.1 for the soon to be released 26.1
* Made version message pretty
* Took deleting mod files out of *minecraft_mod.py* and put it in *__main__.py*

### Security

* Changed python required version to >=3.13 to reflect the supported python versions: [Status of Python versions](https://devguide.python.org/versions/)

## [1.1.0] - 2026-03-12

### Fixed

* Fixed "NameError: name 'Path' is not defined" when trying to delete a mod

## [1.1.0.dev1] - 2026-03-11

### Changed

* Future support for other mod loaders removed

### Removed

* Removed duplicate code in src/mcmu/minecraft_mod.py

## [1.1.0.dev0] - 2026-03-10

### Added

* You can list installed mods now

### Changed

* Started implemented a logging system

## [1.0.0] - 2026-03-10

First stable release.

## [1.0.0rc1] - 2026-03-10

### Changed

* Now only needs mods name not mods URL to install

### Fixed

* Fixed not creating the config file on start

## [1.0.0rc0] - 2026-03-10

This is the first release candidate for version [1.0.0+1.21.11].

### Changed

* Dedicated functions for loading and writing config file

### Fixed

* Fixed "NameError: name 'requests' is not defined" when trying to install a mod

## [0.2.2] - 2026-03-08

### Added

* Added help messages to command line arguments

### Changed

* When no options are present prints help message

## [0.2.1] - 2026-03-07

* Dummy Release

## [0.2.0] - 2026-03-07

### Changed

* Changed name from "MCModUpdater" to "mcm"
* Changed command line arguments around

## [0.1.4] - 2026-03-06

### Fixed

* Fixed Downloading latest mod version instead of latest version for the current installed Minecraft version

### Changed

* Removed some of the debug print statements

## [0.1.3] - 2026-03-06

### Added

* Checks for mod updates

## [0.1.2] - 2026-03-06

### Added

* Now can download and install mods
* Can delete mods

### Fixed

* Script executing twice

## [0.1.1] - 2026-03-06

### Added

* Check Modrinth for mod versions
* Get list of mods from config file
* Add mods to config file

## [0.1.0] - 2026-03-03

*Initial release.*

[0.1.0]: https://github.com/Josiah-Jarvis/MCMU/releases/tag/0.1.0
[0.1.1]: https://github.com/Josiah-Jarvis/MCMU/releases/tag/0.1.1
[0.1.2]: https://github.com/Josiah-Jarvis/MCMU/releases/tag/0.1.2
[0.1.3]: https://github.com/Josiah-Jarvis/MCMU/releases/tag/0.1.3
[0.1.4]: https://github.com/Josiah-Jarvis/MCMU/releases/tag/0.1.4
[0.2.0]: https://github.com/Josiah-Jarvis/MCMU/releases/tag/0.2.0
[0.2.1]: https://github.com/Josiah-Jarvis/MCMU/releases/tag/0.2.1
[0.2.2]: https://github.com/Josiah-Jarvis/MCMU/releases/tag/0.2.2
[1.0.0rc0]: https://github.com/Josiah-Jarvis/MCMU/releases/tag/1.0.0rc0
[1.0.0rc1]: https://github.com/Josiah-Jarvis/MCMU/releases/tag/1.0.0rc1
[1.0.0]: https://github.com/Josiah-Jarvis/MCMU/releases/tag/1.0.0
[1.1.0.dev0]: https://github.com/Josiah-Jarvis/MCMU/releases/tag/1.1.0.dev0
[1.1.0.dev1]: https://github.com/Josiah-Jarvis/MCMU/releases/tag/1.1.0.dev1
[1.1.0]: https://github.com/Josiah-Jarvis/MCMU/releases/tag/1.1.0
[1.1.1a0]: https://github.com/Josiah-Jarvis/MCMU/releases/tag/1.1.1a0
[v1.1.1]: https://github.com/Josiah-Jarvis/MCMU/releases/tag/v1.1.1
[v1.2.0.dev0]: https://github.com/Josiah-Jarvis/MCMU/releases/tag/v1.2.0.dev0
[v1.2.0a0]: https://github.com/Josiah-Jarvis/MCMU/releases/tag/v1.2.0a0
[v1.2.0a1]: https://github.com/Josiah-Jarvis/MCMU/releases/tag/v1.2.0a1
[v1.2.0rc0]: https://github.com/Josiah-Jarvis/MCMU/releases/tag/v1.2.0rc0
[v1.2.0]: https://github.com/Josiah-Jarvis/MCMU/releases/tag/v1.2.0
[v1.2.1]: https://github.com/Josiah-Jarvis/MCMU/releases/tag/v1.2.1
[v1.3.0a0]: https://github.com/Josiah-Jarvis/MCMU/releases/tag/v1.3.0a0
[v1.3.0a1]: https://github.com/Josiah-Jarvis/MCMU/releases/tag/v1.3.0a1
[v1.3.0]: https://github.com/Josiah-Jarvis/MCMU/releases/tag/v1.3.0
[v1.4.0.dev0]: https://github.com/Josiah-Jarvis/MCMU/releases/tag/v1.4.0.dev0
[v2.0.0.dev1]: https://github.com/Josiah-Jarvis/MCMU/releases/tag/v2.0.0.dev0
[v2.0.0.dev2]: https://github.com/Josiah-Jarvis/MCMU/releases/tag/v2.0.0.dev2
[v2.0.0.dev3]: https://github.com/Josiah-Jarvis/MCMU/releases/tag/v2.0.0.dev3
[v2.0.0rc0]: https://github.com/Josiah-Jarvis/MCMU/releases/tag/v2.0.0rc0
[v2.0.0]: https://github.com/Josiah-Jarvis/MCMU/releases/tag/v2.0.0
[v2.0.1.dev0]: https://github.com/Josiah-Jarvis/MCMU/releases/tag/v2.0.1.dev0
[v2.0.1.dev1]: https://github.com/Josiah-Jarvis/MCMU/releases/tag/v2.0.1.dev1
[v2.1.0rc0]: https://github.com/Josiah-Jarvis/MCMU/releases/tag/v2.1.0rc0
[v2.1.0]: https://github.com/Josiah-Jarvis/MCMU/releases/tag/v2.1.0
[v2.1.1]: https://github.com/Josiah-Jarvis/MCMU/releases/tag/v2.1.1
[v2.1.2]: https://github.com/Josiah-Jarvis/MCMU/releases/tag/v2.1.2
[v2.1.3]: https://github.com/Josiah-Jarvis/MCMU/releases/tag/v2.1.3
[v2.2.0.dev0]: https://github.com/Josiah-Jarvis/MCMU/releases/tag/v2.2.0.dev0
[v2.2.0.dev1]: https://github.com/Josiah-Jarvis/MCMU/releases/tag/v2.2.0.dev1
[v2.2.0.dev2]: https://github.com/Josiah-Jarvis/MCMU/releases/tag/v2.2.0.dev2
[v2.2.0.dev3]: https://github.com/Josiah-Jarvis/MCMU/releases/tag/v2.2.0.dev3
[v2.2.0rc0]: https://github.com/Josiah-Jarvis/MCMU/releases/tag/v2.2.0rc0
[v2.2.0]: https://github.com/Josiah-Jarvis/MCMU/releases/tag/v2.2.0
[v2.3.0.dev1]: https://github.com/Josiah-Jarvis/MCMU/releases/tag/v2.3.0.dev1
[v2.3.0.dev2]: https://github.com/Josiah-Jarvis/MCMU/releases/tag/v2.3.0.dev2
[v2.3.0.dev3]: https://github.com/Josiah-Jarvis/MCMU/releases/tag/v2.3.0.dev3
[v2.3.0rc1]: https://github.com/Josiah-Jarvis/MCMU/releases/tag/v2.3.0rc1
[v2.3.0]: https://github.com/Josiah-Jarvis/MCMU/releases/tag/v2.3.0
[v2.4.0.dev1]: https://github.com/Josiah-Jarvis/MCMU/releases/tag/v2.4.0.dev1
[v2.4.0.dev2]: https://github.com/Josiah-Jarvis/MCMU/releases/tag/v2.4.0.dev2
[v2.4.0.dev3]: https://github.com/Josiah-Jarvis/MCMU/releases/tag/v2.4.0.dev3
[v2.4.0.dev4]: https://github.com/Josiah-Jarvis/MCMU/releases/tag/v2.4.0.dev4
[v2.4.0]: https://github.com/Josiah-Jarvis/MCMU/releases/tag/v2.4.0
[v2.5.0.dev1]: https://github.com/Josiah-Jarvis/MCMU/releases/tag/v2.5.0.dev1
